//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by app_four.rc
//
#define IDR_MAINMENU                    102
#define ID_FILE_EXIT                    40001
#define ID_FILE_NEW                     40002
#define ID_FILE_OPEN                    40003
#define ID_FILE_SAVEAS                  40005
#define ID_WINDOW_CASCADE               40008
#define ID_WINDOW_TILE                  40009
#define ID_FILE_CLOSE                   40010
#define ID_FILE_CLOSEALL                40011
#define ID_EDIT_CUT                     40015
#define ID_EDIT_COPY                    40016
#define ID_EDIT_PASTE                   40017

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40020
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
